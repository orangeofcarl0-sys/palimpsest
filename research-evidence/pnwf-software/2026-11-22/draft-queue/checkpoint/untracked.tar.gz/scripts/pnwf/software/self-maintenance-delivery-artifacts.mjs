/**
 * Independent replay for the "prepared review merged, but its artifact is still unnamed" gap.
 *
 * The sealed rejection sessions ended with the review commit at HEAD and no episode record. A
 * resumed session can see that a direct commit exists, but the pulse only said "the committed
 * artifact paths" without naming them; the next turn had to reconstruct Git history to record a
 * verifiable delivery. This oracle reproduces that exact shape: a canonical basis, a prepared
 * review branch merged fast-forward, then only the ordinary pulse and Work tools.
 *
 * It deliberately does not inspect private owner tables to decide what to do. The journal and
 * artifact checks are postconditions, not inputs to the action.
 */
import { execFileSync } from "node:child_process";
import { mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { pathToFileURL } from "node:url";

const candidateRoot = process.cwd();
const { installProduct } = await import(pathToFileURL(join(candidateRoot, "dist/src/product.js")));
const root = mkdtempSync(join(tmpdir(), "maintenance-delivery-artifacts-"));
const git = (...args) => execFileSync("git", ["-C", root, ...args], { encoding: "utf8" }).trim();
const commit = (path, message) => {
  git("add", "--", path);
  git("-c", "user.name=Fixture", "-c", "user.email=fixture@example.invalid", "commit", "-qm", message);
  return git("rev-parse", "HEAD");
};

git("init", "-q");
writeFileSync(join(root, "maintenance.md"), "Maintenance basis\n");
const basis = commit("maintenance.md", "Initial project basis");

const stateDir = mkdtempSync(join(tmpdir(), "maintenance-delivery-artifacts-state-"));
const deployment = installProduct({ tools: { register: () => () => undefined } }, {
  projectId: "delivery-artifacts-repro",
  repository: root,
  stateDir,
  execution: "in-place",
  toolProfile: "normal",
  standard: { statement: "Preserve the documented maintenance review for the next session.", clauses: [], derivedFrom: [], confirmed: true, notes: [] },
});

let ordinal = 0;
function call(name, args) {
  const tool = deployment.tools.find(entry => entry.name === name);
  if (!tool) throw new Error(`Missing ordinary tool ${name}`);
  const callId = `delivery-artifacts-probe-${++ordinal}`;
  return tool.execute(args, { name, callId, rootCallId: callId, arguments: args, signal: AbortSignal.timeout(20_000) });
}

const pulse = () => call("palimpsest_continuity", { action: "pulse" });
const mechanical = value => (value.nextActions?.mechanical ?? []).join("\n");
const firstWorkCommand = value => ((value.nextActions?.mechanical ?? [])[0] ?? "");
const pointsAtConclusion = value => /reply using the recorded conclusion/iu.test(mechanical(value));
const hasEpisode = async () => (await deployment.application.projectWorkspace.journal())
  .some(entry => entry.entry.title.startsWith("Episode conclusion:"));

try {
  await call("palimpsest_start", {
    projectId: "delivery-artifacts-repro",
    goal: "Preserve the committed maintenance review for the next session.",
    headCommit: basis,
    tasks: [],
  });

  // The sealed replay reached this shape: a prepared review commit on `replay`, then a fast-forward
  // merge. The canonical project still points at `basis`; the review is only in Git.
  const branch = git("branch", "--show-current");
  git("switch", "-q", "-c", "replay");
  writeFileSync(join(root, "MAINTENANCE-REVIEW.md"), "# Cold handover maintenance review\n\nREADY\n");
  const prepared = commit("MAINTENANCE-REVIEW.md", "Preserve the committed maintenance review");
  git("switch", "-q", branch);
  git("merge", "--quiet", "--ff-only", "replay");
  const candidate = git("rev-parse", "HEAD");
  if (candidate !== prepared) throw new Error("the prepared review commit was not the merged head");

  const committedPulse = await pulse();
  const required = committedPulse.requiredAction ?? null;
  const offered = Array.isArray(required?.artifacts) ? required.artifacts : [];
  const first = firstWorkCommand(committedPulse);

  const delivery = await call("palimpsest_work", {
    action: "conclude",
    intent: "DELIVER",
    statement: "The merged maintenance review is the preserved work result for this episode.",
    artifacts: offered,
  });
  const recorded = delivery?.conclusion?.check?.artifacts ?? [];
  const review = recorded.find(artifact => artifact.path === "MAINTENANCE-REVIEW.md") ?? null;

  const afterDelivery = await pulse();
  const status = deployment.controller.status();
  const checks = {
    requiredActionPresent: required?.kind === "RECORD_DIRECT_DELIVERY" && required?.repositoryHead === candidate,
    requiredActionNamesTheArtifact: offered.includes("MAINTENANCE-REVIEW.md"),
    firstActionNamesTheArtifact: first.includes("MAINTENANCE-REVIEW.md"),
    executorCanRecordOfferedArtifact: delivery?.state === "RECORDED" &&
      review?.present === true && review?.tracked === true && review?.committed === true && review?.commit === candidate,
    episodeRecordExists: (await hasEpisode()) === true,
    afterDeliveryReusesConclusion: (afterDelivery.requiredAction ?? null) === null &&
      !/palimpsest_work action=/u.test(mechanical(afterDelivery)) && pointsAtConclusion(afterDelivery),
    operatorBasisPreserved: status.headCommit === basis && status.attempts.length === 0 && status.promotions.length === 0,
  };

  console.log("DELIVERY_ARTIFACTS " + JSON.stringify({
    basis,
    candidate,
    offered,
    first,
    deliveryState: delivery?.state ?? null,
    recordedArtifacts: recorded,
    after: {
      requiredAction: afterDelivery.requiredAction ?? null,
      mechanical: afterDelivery.nextActions?.mechanical,
      episode: afterDelivery.episode?.state,
    },
    checks,
  }));
  process.exitCode = Object.values(checks).every(Boolean) ? 0 : 1;
} finally {
  await deployment.dispose();
}
